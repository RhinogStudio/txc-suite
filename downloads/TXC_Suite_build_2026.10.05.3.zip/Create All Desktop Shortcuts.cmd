@echo off
setlocal EnableExtensions
title TXC Suite - Create Desktop Shortcuts

set "FAILED=0"

if not exist "%~dp0TXC Viewer\Create Desktop Shortcut.cmd" (
  echo The TXC Suite files could not be found beside this installer.
  echo.
  echo Extract the complete ZIP to a normal folder before running this file.
  echo Do not run it from inside the ZIP preview.
  echo.
  pause
  exit /b 1
)

echo Creating the TXC Date Tool desktop shortcut...
call "%~dp0TXC Date Tool\Create Desktop Shortcut.cmd"
if errorlevel 1 set "FAILED=1"

echo.
echo Creating the TXC Viewer desktop shortcut...
call "%~dp0TXC Viewer\Create Desktop Shortcut.cmd"
if errorlevel 1 set "FAILED=1"

echo.
echo Creating the TXC Validator desktop shortcut...
call "%~dp0TXC Validator\Create Desktop Shortcut.cmd"
if errorlevel 1 set "FAILED=1"

echo.
if "%FAILED%"=="0" (
  echo All three shortcut installers completed successfully.
) else (
  echo One or more shortcuts could not be created.
  echo Please review the error shown above.
)
echo.
echo Press any key to close this window.
pause >nul

endlocal
