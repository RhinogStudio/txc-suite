@echo off
setlocal

echo Removing the TXC Date Tool desktop shortcut...
call "%~dp0TXC Date Tool\Remove Desktop Shortcut.cmd"

echo.
echo Removing the TXC Viewer desktop shortcut...
call "%~dp0TXC Viewer\Remove Desktop Shortcut.cmd"

echo.
echo Removing the TXC Validator desktop shortcut...
call "%~dp0TXC Validator\Remove Desktop Shortcut.cmd"

endlocal
