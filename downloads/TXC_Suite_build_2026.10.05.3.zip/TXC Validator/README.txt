TXC Validator — Portable Desktop App
====================================

Keep this entire folder together, then double-click:
Create Desktop Shortcut.cmd

This creates a desktop shortcut with the purple validation icon and opens the
local HTML tool in Microsoft Edge's standalone app mode.

The validator accepts individual TXC XML files, ZIP archives and complete
folders. It highlights expired services in red and services expiring within
the next 31 days in yellow. It also flags missing or NULL initial journey-
pattern destination displays, broken journey-pattern section references,
broken VehicleJourney pattern references, and explicit inbound/outbound
direction mismatches. It checks the registered operator has a NationalOperatorCode
or OperatorCode (used for the NOC in some general TXC exports), and that the
StandardService has a published Origin and Destination.
It also warns when a VehicleJourney has no usable
Operational/TicketMachine/JourneyCode.
Date results and data-check results are shown separately.

Operator identifiers are reported at two levels: missing both codes is an error;
an OperatorCode without a NationalOperatorCode is a warning; and a supplied
NationalOperatorCode passes. Both values are displayed and included in CSV exports.
Scanning is read-only and works offline.

Nothing is installed. The shortcut can be removed using:
Remove Desktop Shortcut.cmd

The tool can also be launched without creating a shortcut using:
Open TXC Validator.cmd

If this folder is moved, recreate the shortcut from its new location.
