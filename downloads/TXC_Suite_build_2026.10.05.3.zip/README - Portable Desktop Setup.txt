TXC Suite
=========

This pack contains three non-installing, offline browser tools:

1. TXC Date Tool
   Blue calendar/date-change desktop icon.

2. TXC Viewer
   Teal bus/timetable desktop icon.

3. TXC Validator
   Purple document/check desktop icon with expiry status colours.

FIRST-TIME SETUP
----------------
1. Extract the complete ZIP to a permanent location.
   Examples:
   - Documents\TXC Suite
   - Desktop\TXC Suite
   - An approved team folder on your computer

2. Do not run the tools from inside the ZIP.

3. Double-click:
   Create All Desktop Shortcuts.cmd

4. Windows creates three desktop shortcuts with separate names and icons.

USING THE TOOLS
---------------
Open the desktop shortcuts. Each tool opens Microsoft Edge in a standalone
app-style window without the normal Edge tabs and address bar.

Nothing is installed. The shortcuts point to:
- Microsoft Edge already installed on the computer;
- the local HTML files inside this portable folder;
- the local ICO files inside this portable folder.

The TXC Validator accepts individual TXC XML files, ZIP files and
complete folders. It reports expired services in red and services due to expire
within the next 31 days in yellow. It is read-only and does not alter TXC data.

IMPORTANT
---------
Keep this extracted folder in the same location. If it is moved, the desktop
shortcuts will still point to the old location. Run
Create All Desktop Shortcuts.cmd again after moving it.

FALLBACK
--------
If workplace policy blocks automatic shortcut creation, each folder contains
an Open Tool .cmd file. The HTML files can also be opened directly in Edge.

REMOVAL
-------
Run Remove All Desktop Shortcuts.cmd or delete the three desktop shortcuts
manually. Deleting this portable folder removes the tools themselves.

No administrator rights, installer, registry changes, browser extension,
internet connection or external web resources are required.
