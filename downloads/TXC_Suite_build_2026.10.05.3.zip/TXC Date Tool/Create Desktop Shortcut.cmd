@echo off
setlocal EnableExtensions

set "APP_NAME=TXC Date Tool"
set "HTML=%~dp0TXC Date Tool.html"
set "ICON=%~dp0TXC Date Tool.ico"

if not exist "%HTML%" (
  echo The HTML tool could not be found:
  echo %HTML%
  echo.
  pause
  exit /b 1
)

if not exist "%ICON%" (
  echo The icon file could not be found:
  echo %ICON%
  echo.
  pause
  exit /b 1
)

set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"

if not exist "%EDGE%" (
  set "EDGE_FOUND="
  for /f "delims=" %%E in ('where msedge.exe 2^>nul') do (
    if not defined EDGE_FOUND set "EDGE_FOUND=%%E"
  )
  if defined EDGE_FOUND set "EDGE=%EDGE_FOUND%"
)

if not exist "%EDGE%" (
  echo Microsoft Edge could not be found.
  echo.
  pause
  exit /b 1
)

set "TXC_APP_NAME=%APP_NAME%"
set "TXC_HTML=%HTML%"
set "TXC_ICON=%ICON%"
set "TXC_EDGE=%EDGE%"

powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; $desktop=[Environment]::GetFolderPath('Desktop'); $shortcutPath=Join-Path $desktop ($env:TXC_APP_NAME + '.lnk'); $shell=New-Object -ComObject WScript.Shell; $shortcut=$shell.CreateShortcut($shortcutPath); $uri='file:///' + ($env:TXC_HTML -replace '\\','/'); $shortcut.TargetPath=$env:TXC_EDGE; $shortcut.Arguments='--app=\"' + $uri + '\"'; $shortcut.WorkingDirectory=Split-Path $env:TXC_HTML; $shortcut.IconLocation=$env:TXC_ICON + ',0'; $shortcut.Description=$env:TXC_APP_NAME + ' - offline browser tool'; $shortcut.Save()"

if errorlevel 1 (
  echo.
  echo The desktop shortcut could not be created.
  echo Your organisation may block shortcut-creation scripts.
  echo The tool can still be opened using the Open Tool file.
  echo.
  pause
  exit /b 1
)

echo.
echo Desktop shortcut created:
echo %APP_NAME%
echo.
echo The portable folder must stay in this location.
echo If it is moved, run this file again to recreate the shortcut.
echo.
pause

endlocal
