@echo off
setlocal EnableExtensions

set "TXC_APP_NAME=TXC Date Tool"

powershell.exe -NoProfile -Command "$desktop=[Environment]::GetFolderPath('Desktop'); $shortcutPath=Join-Path $desktop ($env:TXC_APP_NAME + '.lnk'); if (Test-Path -LiteralPath $shortcutPath) { Remove-Item -LiteralPath $shortcutPath -Force }"

if errorlevel 1 (
  echo The desktop shortcut could not be removed automatically.
  echo You can delete it from the desktop manually.
  echo.
  pause
  exit /b 1
)

echo.
echo Desktop shortcut removed, if it existed.
echo.
pause

endlocal
