TXC Viewer — Portable Desktop App
=================================

Keep this entire folder together, then double-click:
Create Desktop Shortcut.cmd

This creates a desktop shortcut with the teal bus/timetable icon and opens the
local HTML viewer in Microsoft Edge's standalone app mode.

Nothing is installed. The shortcut can be removed using:
Remove Desktop Shortcut.cmd

The viewer can also be launched without creating a shortcut using:
Open TXC Viewer.cmd

If this folder is moved, recreate the shortcut from its new location.
