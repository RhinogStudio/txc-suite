@echo off
setlocal EnableExtensions

set "HTML=%~dp0TXC Viewer.html"

if not exist "%HTML%" (
  echo The HTML tool could not be found:
  echo %HTML%
  echo.
  pause
  exit /b 1
)

set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"

if not exist "%EDGE%" (
  set "EDGE_FOUND="
  for /f "delims=" %%E in ('where msedge.exe 2^>nul') do (
    if not defined EDGE_FOUND set "EDGE_FOUND=%%E"
  )
  if defined EDGE_FOUND set "EDGE=%EDGE_FOUND%"
)

if not exist "%EDGE%" (
  echo Microsoft Edge could not be found.
  echo Please open the HTML file directly in Edge instead.
  echo.
  pause
  exit /b 1
)

set "HTML_URL=file:///%HTML:\=/%"
start "" "%EDGE%" --app="%HTML_URL%"

endlocal
